package com.example.project_lofi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectLofiApplicationTests {

	@Test
	void contextLoads() {
	}

}
